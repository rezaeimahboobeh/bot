<?php
$admin_id = "243656719";
$botToken= "773565947:AAE73ByBtaX8Rwf3NTVZXypOtf8FZGZ7DDk";
$website= "https://api.telegram.org/bot$botToken/";

//get info from telegram
$update=file_get_contents("php://input");
if ($update === FALSE) {
  echo "Wrong!!";
} else {
  echo "Update is $update";
  $arrayupdate=json_decode($update,TRUE);
  $ok = $arrayupdate["ok"];
  file_get_contents ($website."sendmessage?text=".$ok."&chat_id=".$admin_id);
}

//send info to telegram
//$arrayupdate=json_decode($update,TRUE);
//$chat_id = $update ['message']['chat']['id'];

//print_r($arrayupdate);
/*$end1=end($arrayupdate);
//print_r( $end1);
$end2=end($end1);
//print_r($end2);
$end3=end($end2);
//print_r($end3);
$end4=end($end3);
//echo $end4;
//$keys = array_keys($arrayupdate);
//$lastKey = $keys[count($keys)-1];
//echo $lastKey;
$chatid=$arrayupdate["result"][0]["message"]["chat"]["id"];
//echo $chatid;
//file_get_contents($website."/sendMessage?chat_id=".$chatid."&text=test0");
echo $end4 ."is id <br>";
/*
$con = mysqli_connect("localhost","root","","branch");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  $sql="SELECT * FROM address WHERE  id=".$end4."";
  $result = $con->query($sql);
  $row = $result->fetch_assoc();

  echo $row['name'];
  $name=$row['name'];
file_get_contents($website."/sendMessage?chat_id=".$chatid."&text=".$name);
*/

 ?>
